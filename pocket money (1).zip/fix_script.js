const fs = require('fs');
fs.copyFileSync('firebase-applet-config.json', 'public/firebase-applet-config.json');

